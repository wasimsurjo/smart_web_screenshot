# Info

A smart web screenshot taker that is designed to bypass several issues commonly faced by scapers